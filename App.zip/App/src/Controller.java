import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class Controller {

    @FXML
    private Label Numero;
    private int qsy = 0; 

    @FXML
    void Menos(ActionEvent event) {
        qsy--;
        actualizar();
    }

    @FXML
    void Mas(ActionEvent event) {
        qsy++; 
        actualizar();
    }

    private void actualizar() {
        Numero.setText(String.valueOf(qsy));
    }
}
