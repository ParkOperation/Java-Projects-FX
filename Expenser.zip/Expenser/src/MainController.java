import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.cell.PropertyValueFactory;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;


public class MainController {
    
    @FXML
    TextField moneyField; 
    @FXML
    TextField descField; 

    @FXML
    private Alert alerta  = new Alert(AlertType.ERROR);

    @FXML
    private ComboBox<String> categories; 
    
    @FXML
    private TableColumn<Expense, String> category; 
    
    @FXML
    private TableColumn<Expense, String> description; 
    
    @FXML
    private TableColumn<Expense, Number> expense; 
    
    @FXML
    private TableView<Expense> table; 
    
    private final ObservableList<Expense> expenses = FXCollections.observableArrayList();

    @FXML
    private Label total;

    @FXML
    void AddExpense(ActionEvent event) {
        String selectedCategory = categories.getValue();
        String description = descField.getText();
        String evaluate = moneyField.getText();
        if(selectedCategory == null){
            alerta.setTitle("Something is wrong");
            alerta.setHeaderText("Category is empty");
            alerta.showAndWait();
        }
        else if(description == null || description.isEmpty()){
            alerta.setTitle("Something is wrong");
            alerta.setHeaderText("Description is empty");
            alerta.showAndWait();
            
        }else if(evaluate == null || evaluate.isEmpty()){
            alerta.setTitle("Something its wrong");
            alerta.setHeaderText("Money is empty");
            alerta.showAndWait();
            
        }
        else{
        double amount = Double.parseDouble(moneyField.getText());
        double numbertotal =+ amount;
        double currentspent = Double.valueOf(total.getText());
        total.setText(String.valueOf(currentspent + amount));
        
        

        Expense newExpense = new Expense(selectedCategory, description, amount);
        expenses.add(newExpense);

        categories.setValue(null);
        descField.clear();
        moneyField.clear();

        writeExpenseToFile(newExpense);

        }
    }

    private void writeExpenseToFile(Expense expense) {
        File file = new File("expenses.txt");
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
            writer.write(expense.getCategory() + " - $" + expense.getExpense() + System.lineSeparator());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void initialize(){
        categories.getItems().addAll("Food", "Transport", "Utilities");
        table.setItems(expenses);

        category.setCellValueFactory(new PropertyValueFactory<>("category"));
        description.setCellValueFactory(new PropertyValueFactory<>("description"));
        expense.setCellValueFactory(new PropertyValueFactory<>("expense"));
    }

}

