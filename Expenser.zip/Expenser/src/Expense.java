public class Expense {
    private String category;
    private String description;
    private double expense; 

    
    public Expense(String category, String description, double expense) {
        this.category = category;
        this.description = description;
        this.expense = expense;
    }

    
    public String getCategory() {
        return category;
    }

    public String getDescription() {
        return description;
    }

    public double getExpense() {
        return expense;
    }

    
    public void setCategory(String category) {
        this.category = category;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setExpense(double expense) {
        this.expense = expense;
    }

    @Override
    public String toString() {
        return "Expense{" +
               "category='" + category + '\'' +
               ", description='" + description + '\'' +
               ", expense=" + expense +
               '}';
    }
}
