import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;


public class Controller {
    @FXML
    private HBox StudentBox;

    @FXML
    private TextField mytextfield;
    
    @FXML
    void cleartext(ActionEvent event){
        mytextfield.clear();

    }

    @FXML
    void crearEstudiante(ActionEvent event) {
        Student student = new Student(mytextfield.getText(), 0);
        Button addButton = new Button();
        ((HBox)((Button) addButton).getParent()).getChildren().add(student);
        System.out.println("student created.");



        // try {
        //     StudentBox.getChildren().add(student);

        //     System.out.println("Student created");
            
        // } catch (Exception e) {
        //     // TODO: handle exception
        // }
       
        

    }


}
