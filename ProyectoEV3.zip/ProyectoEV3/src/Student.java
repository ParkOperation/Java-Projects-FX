import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
 
public class Student extends HBox{

    private String name;
    private int points;
    private Label nameLabel;
    private Label pointsLabel;
    private Button minusButton;
    private Button plusButton;
 
    public Student(String name, int points) {
        this.name = name;
        this.points = points;
 
        nameLabel = new Label(name);
        pointsLabel = new Label(Integer.toString(points));
        minusButton = new Button("-");
        plusButton = new Button("+");
 
        minusButton.setOnAction(e -> subtractPoint());
        plusButton.setOnAction(e -> addPoint());

        setSpacing(10);
        setAlignment(Pos.CENTER);
        getChildren().addAll(nameLabel,pointsLabel, minusButton, plusButton);

        Rectangle background = new Rectangle(150,50,Color.GRAY);
        setClip(background);
    }
 
    private void subtractPoint() {
        points--;
        updatePointsLabel();
    }
 
    private void addPoint() {
        points++;
        updatePointsLabel();
    }
 
    private void updatePointsLabel() {
        pointsLabel.setText(Integer.toString(points));
    }
 
    public void addToLayout() {
        HBox studentLayout = new HBox(10);
        studentLayout.setAlignment(Pos.CENTER);
        studentLayout.getChildren().addAll(nameLabel, pointsLabel, minusButton, plusButton);
        ((HBox) nameLabel.getParent()).getChildren().add(studentLayout);
    }
}